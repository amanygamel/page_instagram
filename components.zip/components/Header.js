
import {View,Text,StyleSheet,Image}  from 'react-native';
import { Entypo } from '@expo/vector-icons';
import CircularImage from './CircularImage';
export default function Header({username,nickname}){
  
return (<View style={styles.headerContainer}>
      
     <View style={{flex:1,flexDirection:"row",padding:5 }}> 
     
        <CircularImage width={80} height={80}/> 
     
     <View>
      <Text style={styles.username}>{username}</Text>
      <Text style={styles.nickname}>{nickname}</Text>
      </View>
       </View>
      <Entypo name="dots-three-vertical" size={21} color="gray" style={{padding:5}} />
</  View>)


}

const styles = StyleSheet.create({
  headerContainer:{
      flex:1,
      flexDirection:"row",
      justifyContent:"space-between",
      alignContent:"center",
      

  },
  username: {
    fontSize: 17,
    fontWeight: 'bold',
    marginTop:5,
  },
  nickname: {
    color: 'grey',
    fontStyle: 'italic',
  },
});
