
import {View} from "react-native";
import CircularImage from './CircularImage';
import Header from './Header';
import Footer from './Footer';
import Content from './Content';
const Post =()=>{
  return(
     <>
      <View style={{flex:1,marginVertical:8}}>
      <Header username="Amany gamal" nickname="@Amany.gamal"/>
      </View>
      
      <View style={{flex:4}}>
      <Content />
      </View>
      <View style={{flex:1,marginTop:10}}>
      <Footer />
      </View>
      </>
  );
}

export default Post;